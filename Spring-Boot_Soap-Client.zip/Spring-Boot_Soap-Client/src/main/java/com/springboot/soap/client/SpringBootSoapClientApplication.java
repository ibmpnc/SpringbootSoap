package com.springboot.soap.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.springboot.soap.api.loaneligibility.Acknowledgement;
import com.springboot.soap.api.loaneligibility.CustomerRequest;
import com.springboot.soap.client.config.SoapClinet;


@SpringBootApplication
@RestController
public class SpringBootSoapClientApplication {

	
	@Autowired
	private SoapClinet clinet;
	
	
	@PostMapping("/getLoanStatus")
	public Acknowledgement invokeSoapClientToGetLoanStatus(@RequestBody CustomerRequest request) {
		return clinet.getLoanStatus(request);
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootSoapClientApplication.class, args);
	}

}
