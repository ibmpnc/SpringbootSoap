package com.springboot.soap.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSoapClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
