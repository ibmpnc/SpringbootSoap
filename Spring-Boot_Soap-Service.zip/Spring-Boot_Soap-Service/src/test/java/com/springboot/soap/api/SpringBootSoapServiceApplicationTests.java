package com.springboot.soap.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSoapServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
